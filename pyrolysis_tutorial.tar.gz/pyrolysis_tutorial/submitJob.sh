#!/bin/bash -x
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --ntasks-per-node=32
#SBATCH --output=mpi-out.%j
#SBATCH --error=mpi-err.%j
#SBATCH --time=08:00:00
#SBATCH --partition=batch
### start of jobscript

WORKDIR=$PWD
cd $WORKDIR
echo "workdir: $WORKDIR"
NSLOTS=64
echo "running on $NSLOTS cpus ..."

module use /usr/local/software/jureca/OtherStages
module load Stages/Devel
module load Intel/2017.1.132-GCC-5.4.0 ParaStationMPI/5.1.5-1

module load OpenFOAM/2.4.0


source $FOAM_BASH

blockMesh >& log.blockMesh
topoSet >& log.topoSet
extrudeToRegionMesh -overwrite >& log.extrudeToRegionMesh
# parallel run
#srun -n 1 decomposePar
#srun -n decomposePar -force >& log.decomposePar.primaryRegion
#srun -n 1 decomposePar -force -region filmRegion >& log.decomposePar.filmRegion
#srun -n 1 decomposePar -force -region pmmaRegion >& log.decomposePar.pyrolysisRegion
#srun -n $NSLOTS fireFoam24 -parallel >& log.fireFoam
#srun -n 1 reconstructPar -allRegions >& log.reconstructPar
#srun -n 1 rm -r processor*

# serial run
srun -n $NSLOTS fireFoam24 >& log.fireFoam

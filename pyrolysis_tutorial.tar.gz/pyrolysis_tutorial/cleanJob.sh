rm -fr log.*
rm -fr processor*
rm -fr outFlameHeight*
rm -fr constant/polyMesh constant/pmmaRegion/polyMesh
rm -fr 1* 2* 3* 4* 5* 6* 7* 8* 9*
